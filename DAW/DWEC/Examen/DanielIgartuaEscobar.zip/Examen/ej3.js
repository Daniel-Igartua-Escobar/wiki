function cargar() {
    let peticion = indexedDB.open('baseDatos', '1');

    peticion.addEventListener('success', function (e) {
        bd = e.target.result;
        console.log('Almacen ya existe');
    })

    peticion.addEventListener('upgradeneeded', function (e) {
        bd = e.target.result;
        let almacenTareas = bd.createObjectStore('tareas', { autoIncrement: true });
        almacenTareas.transaction.addEventListener('complete',() => { console.log('Almacen creado')});
        almacenTareas.transaction.addEventListener('error',() => { console.log('error')});
    })

}

function añadirTarea() {
    let transac = bd.transaction('tareas', 'readwrite');
    let almacenTareas = transac.objectStore('tareas');
    transac.addEventListener('complete', () => console.log('transacción ok'));
    transac.addEventListener('error', () =>  console.log('transacción nok'));
    let registro = {'nombre': nombre.value, 'completada': tarea.value };
    let peticAdd = almacenTareas.add(registro);
    peticAdd.addEventListener('success',() => console.log('Inserción ok'));
    peticAdd.addEventListener('error',() => console.log('Inserción nok'));
}

function tareasPendientes() {
    let transac = bd.transaction('tareas', 'readonly');
    let almacenTareas = transac.objectStore('tareas');
    transac.addEventListener('complete',() => { console.log('transacción ok')});
    transac.addEventListener('error',() => { console.log('transacción nok')});
    let ordenLect = almacenTareas.getAll();
    ordenLect.addEventListener('success',(e) => {
        console.log(e)
        debugger;
        let datoLeido = e.target.result;
        if (datoLeido) console.log(datoLeido)
        else console.log('error getAll')
    });

    ordenLect.addEventListener('error',() => console.log('error en lectura'));
}

function mostrarTareas(tarea) {
    document.getElementById('resultados').innerHTML = `Tarea pendiente=${tarea}`;
}